<?php
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use App\Models\Form; 

class FormController extends Controller
{
    public function showForm()
    {
        return view('form');
    }

    public function submitForm(Request $request)
{
    $validator = Validator::make($request->all(), [
        'username' => 'required|string|max:255',
        'password' => 'required|string|min:6',
        'email' => 'required|email',
        'NIK' => 'required|string|max:17',
        'phonenumber' => 'required|string|max:12',        
        'image' => 'required|image|mimes:jpeg,jpg,png|max:2048',
        'file' => 'required|mimes:pdf,doc,docx',
        'video' => 'required|mimetypes:video/mp4,video/avi',
    ]);

    if ($validator->fails()) {
        return redirect('/form')
            ->withErrors($validator)
            ->withInput();
    }

    $image = $request->file('image');
    $imageName = time() . '.' . $image->extension();
    $image->move(public_path('images'), $imageName);

    $file = $request->file('file');
    $fileName = time() . '.' . $file->extension();
    $file->move(public_path('files'), $fileName);

    $video = $request->file('video');
    $videoName = time() . '.' . $video->extension();
    $video->move(public_path('videos'), $videoName);

    $form = new Form([
        'username' => $request->input('username'),
        'password' => bcrypt($request->input('password')),
        'email' => $request->input('email'),
        'NIK' => $request->input('NIK'), 
        'phonenumber' => $request->input('phonenumber'), 
        'image' => $imageName,
        'file' => $fileName,
        'video' => $videoName,
    ]);

    $form->save();

    return redirect('/success');
}
}